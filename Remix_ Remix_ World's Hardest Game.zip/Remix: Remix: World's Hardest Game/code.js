var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["962942d6-6641-4838-8c70-07c4d49f4fa9","a03929dd-d49d-42a6-b187-547e4e209467","c4aa392e-cae4-4e2d-9170-a464ca64df1e","d23843a3-54c2-4fb3-8413-19aeeec3e68b","8757c87c-7eea-4e7a-9eb2-8b57b0a3c0fe","ccd24f61-9d8f-4a87-ac26-be35f84dc0c5","cbc0a63f-b698-4d6e-95f1-f6e9c64b3d22"],"propsByKey":{"962942d6-6641-4838-8c70-07c4d49f4fa9":{"name":"monster1","sourceUrl":"assets/api/v1/animation-library/gamelab/bSvHi.1CZI.Ys5vkrK4kJJiGBaWZz_Tn/category_fantasy/alien_18.png","frameSize":{"x":261,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"bSvHi.1CZI.Ys5vkrK4kJJiGBaWZz_Tn","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":261,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/bSvHi.1CZI.Ys5vkrK4kJJiGBaWZz_Tn/category_fantasy/alien_18.png"},"a03929dd-d49d-42a6-b187-547e4e209467":{"name":"monster2","sourceUrl":"assets/api/v1/animation-library/gamelab/I6lmT7QNqceMLAtvM.vAJ.bHxygFLgvC/category_fantasy/alien_09.png","frameSize":{"x":259,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"I6lmT7QNqceMLAtvM.vAJ.bHxygFLgvC","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":259,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/I6lmT7QNqceMLAtvM.vAJ.bHxygFLgvC/category_fantasy/alien_09.png"},"c4aa392e-cae4-4e2d-9170-a464ca64df1e":{"name":"monster3","sourceUrl":"assets/api/v1/animation-library/gamelab/nVBK1OnWogFitvGAbWs4ey1tFRWCwaVl/category_fantasy/alien_01.png","frameSize":{"x":365,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"nVBK1OnWogFitvGAbWs4ey1tFRWCwaVl","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":365,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/nVBK1OnWogFitvGAbWs4ey1tFRWCwaVl/category_fantasy/alien_01.png"},"d23843a3-54c2-4fb3-8413-19aeeec3e68b":{"name":"monster4","sourceUrl":"assets/api/v1/animation-library/gamelab/Mz9t_vVZ_K7DL7e61UbY1ivgFlG0hkqh/category_fantasy/alien_04.png","frameSize":{"x":347,"y":392},"frameCount":1,"looping":true,"frameDelay":2,"version":"Mz9t_vVZ_K7DL7e61UbY1ivgFlG0hkqh","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":347,"y":392},"rootRelativePath":"assets/api/v1/animation-library/gamelab/Mz9t_vVZ_K7DL7e61UbY1ivgFlG0hkqh/category_fantasy/alien_04.png"},"8757c87c-7eea-4e7a-9eb2-8b57b0a3c0fe":{"name":"monster5","sourceUrl":"assets/api/v1/animation-library/gamelab/_Fss9nfE5lNH0kxcazbNg2Dxl7rbZDBA/category_fantasy/alien_13.png","frameSize":{"x":349,"y":398},"frameCount":1,"looping":true,"frameDelay":2,"version":"_Fss9nfE5lNH0kxcazbNg2Dxl7rbZDBA","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":349,"y":398},"rootRelativePath":"assets/api/v1/animation-library/gamelab/_Fss9nfE5lNH0kxcazbNg2Dxl7rbZDBA/category_fantasy/alien_13.png"},"ccd24f61-9d8f-4a87-ac26-be35f84dc0c5":{"name":"HOUSE","sourceUrl":"assets/api/v1/animation-library/gamelab/SdWQxWCDyex8hClWCHLD12UVJYsbTgk9/category_buildings/house_04.png","frameSize":{"x":396,"y":275},"frameCount":1,"looping":true,"frameDelay":2,"version":"SdWQxWCDyex8hClWCHLD12UVJYsbTgk9","categories":["buildings"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":396,"y":275},"rootRelativePath":"assets/api/v1/animation-library/gamelab/SdWQxWCDyex8hClWCHLD12UVJYsbTgk9/category_buildings/house_04.png"},"cbc0a63f-b698-4d6e-95f1-f6e9c64b3d22":{"name":"girl","sourceUrl":"assets/api/v1/animation-library/gamelab/CxA8ktK5EbiEj1DPMgO9nyxT0U0TebgK/category_faces/kidportrait_15.png","frameSize":{"x":284,"y":353},"frameCount":1,"looping":true,"frameDelay":2,"version":"CxA8ktK5EbiEj1DPMgO9nyxT0U0TebgK","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":284,"y":353},"rootRelativePath":"assets/api/v1/animation-library/gamelab/CxA8ktK5EbiEj1DPMgO9nyxT0U0TebgK/category_faces/kidportrait_15.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----



girl = createSprite(25,82,30,30);
girl.setAnimation( "girl");
girl.scale=0.15

var line = createSprite(200,200,400,5);

var monster1 = createSprite(130,10,20,20);
monster1.setAnimation("monster1");
monster1.scale=0.1

var monster2 = createSprite(220,175,20,20);
monster2.setAnimation("monster2");
monster2.scale=0.07

var monster3 = createSprite(330,10,20,20);
monster3.setAnimation( "monster3");
monster3.scale=0.1

var monster4 = createSprite(95,230,20,20);
monster4.setAnimation( "monster4");
monster4.scale=0.1

var monster5= createSprite(190,385,20,20);
monster5.setAnimation(  "monster5");
monster5.scale=0.1

var house = createSprite(330,340,100,150);
house.setAnimation( "HOUSE");
house.scale=0.25

monster1.velocityY=8;
monster2.velocityY=-8;
monster3.velocityY=8;
monster4.velocityY=8;
monster5.velocityY=-8;


var DeathCount=0;



function draw() {
  background("white")
  
 createEdgeSprites()

girl.bounceOff(line);
 girl.bounceOff(topEdge);
  girl.bounceOff(bottomEdge);
 monster1.bounceOff(line);
 monster2.bounceOff(line);
 monster3.bounceOff(line);
 monster4.bounceOff(line);
 monster5.bounceOff(line);
 monster1.bounceOff(topEdge);
monster2.bounceOff(topEdge);
monster3.bounceOff(topEdge);
monster4.bounceOff(bottomEdge);
monster5.bounceOff(bottomEdge);
  
  
  if(girl.isTouching(monster1)||
  girl.isTouching(monster2)||
  girl.isTouching(monster3)||
  girl.isTouching(monster4)||
  girl.isTouching(monster5))
  {
    girl.x=25;
    girl.y=82;
    DeathCount=DeathCount +1;
  }
  
  if (girl.isTouching(leftEdge))
  {
    girl.x=25;
    girl.y=82;
  }
  
  if (girl.isTouching(rightEdge))
  {
    girl.x=30;
    girl.y=304;
  }
  

  if(keyDown(RIGHT_ARROW))
  {
    girl.x=girl.x +4
  }
  
  if(keyDown(LEFT_ARROW))
  {
    girl.x=girl.x -4
  }  
  
  if(keyDown(UP_ARROW))
  {
    girl.y=girl.y -4
  }
  
  if (keyDown(DOWN_ARROW))
  {
    girl.y= girl.y +4
  }
  
  if (girl.isTouching(house))
  {
    monster1.velocityY=0;
   monster2.velocityY=0;
    monster3.velocityY=0;
   monster4.velocityY=0;
    monster5.velocityY=0;
    textSize(30)
    fill("BLACK")
    text(" GAME OVER YOU WON!!!",0,200);
  }
  
  textSize(20)
  fill("blue")
  text("Deaths:"+DeathCount,290,250);
 
  
 drawSprites()
 
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
